import java.util.Scanner;

public class task1{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double tempInf=sc.nextDouble();
        double tempInc=sc.nextDouble();

        double tempInC =((tempInf-32)*5)/9;
        double tempInF=(((1.8)* tempInC)+32);
        System.out.println("temperature in C = " + tempInC);
        System.out.println("temperature in F = " + tempInF);
    }
}

